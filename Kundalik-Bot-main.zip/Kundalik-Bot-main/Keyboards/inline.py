from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

kundalikcom_button = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Kundalik Com", url="https://emaktab.uz/")
        ]
    ]
)